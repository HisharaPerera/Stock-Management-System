<?php


if(!mysql_connect("mysql.hostinger.in","u663784695_hish","hish@123"))
{
     die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("u663784695_print"))
{
     die('oops database selection problem ! --> '.mysql_error());
}
?>