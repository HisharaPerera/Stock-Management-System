<?php
include "../config.php";
$supId = $_POST['supId'];
$orderDate = $_POST['orderDate'];
$delDate = $_POST['delDate'];
$remarks = $_POST['remarks'];
if($supId != null && $orderDate != null && $delDate != null && $remarks != null){
$stmt = $conn->prepare("INSERT INTO supplier_order VALUES ('',?,?,?,?)");
$stmt->bind_param('ssss', $supId, $orderDate, $delDate, $remarks);

if($stmt->execute()){
?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Success!</strong>
</div>
<?php
} else{
?>
<div class="alert alert-danger alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Error!</strong> 
</div>
<?php
}
} else{
?> 
<div class="alert alert-warning alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Warning!</strong> 
</div>
<?php
}
?>
