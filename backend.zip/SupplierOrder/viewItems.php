

  <!-- Table -->
  <table class="table">

    <thead>
    <tr>
      <th>Item ID</th>
      <th>Quantity</th>
    </tr>
  </thead>
    <tbody>

<?php
include "../config.php";
$id = $_GET['id'];
$res4 = $conn->prepare("select * from supplier_order where orderId='$id'");
while ($row = $res4->fetch_assoc()) {
?>

<div class="modal fade" id="myModal2<?php echo $row['orderId']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $row['orderId']; ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form>
  <div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Order details</div>
  <div class="panel-body">
    <p>...</p>
  </div>

<tr>
      <td><?php echo $row['itemId']; ?></td>
      <td><?php echo $row['quantity']; ?></td>
    </tr>
    </div>
</form>
      
      </div>
    </div>
  </div>
</div>
      <?php
}
?>
    </tbody>


  </table>
