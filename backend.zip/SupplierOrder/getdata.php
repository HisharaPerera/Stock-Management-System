<table class="table table-bordered table-hover">
	<thead>
   <tr>
    <th>Order ID</th>
    <th>Supplier ID</th>
    <th>Order Date</th>
    <th>Delivery Date</th>
    <th>Remarks</th>
    <th>View/Edit/Delete</th>
  </tr>
</thead>
<tbody>
  <?php
  include "../config.php";
  $res = $conn->query("select * from supplier_order");
  while ($row = $res->fetch_assoc()) {
    ?>
    
    <tr>
     <td><?php echo $row['orderId']; ?></td>
     <td><?php echo $row['supId']; ?></td>
     <td><?php echo $row['orderDate']; ?></td>
     <td><?php echo $row['delDate']; ?></td>
     <td><?php echo $row['remarks']; ?></td>
     <td>
      <!--<a class="btn btn-success btn-sm"  onclick="href='viewItems.php?id=$row['orderId']'" ><span class="glyphicon glyphicon glyphicon-file" aria-hidden="true"></span></a>-->
      <a class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal<?php echo $row['orderId']; ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
      <a class="btn btn-danger btn-sm"  onclick="deletedata('<?php echo $row['orderId']; ?>')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>


      <!-- Modal -->
      <div class="modal fade" id="myModal<?php echo $row['orderId']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $row['orderId']; ?>" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="myModalLabel<?php echo $row['orderId']; ?>">Edit Order</h4>
            </div>
            <div class="modal-body">

              <form>
                <div class="form-group">
                  <label for="supId">Supplier ID</label>
                  <select class="form-control" id="supId">
                    <?php 
                    $res2 = $conn->query("select supId from supplier");
                    while ($row = $res2->fetch_assoc()) {
                      echo "<option value=\"supId\">" . $row['supId'] . "</option>";
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="orderDate">Order Date</label>
                  <input type="text" class="form-control" id="orderDate<?php echo $row['orderId']; ?>" value="<?php echo $row['orderDate']; ?>">
                </div>
                <div class="form-group">
                  <label for="delDate">Delivery Date</label>
                  <input type="text" class="form-control" id="delDate<?php echo $row['orderId']; ?>" value="<?php echo $row['delDate']; ?>">
                </div>
                <div class="form-group">
                  <label for="remarks">Remarks</label>
                  <textarea type="text" class="form-control" rows="5" id="remarks<?php echo $row['orderId']; ?>" value="<?php echo $row['remarks']; ?>"></textarea>
                </div>
              </form>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="button" onclick="updatedata('<?php echo $row['orderId']; ?>')" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>

    </td>
  </tr>
  <?php
}
?>
</tbody>
</table>