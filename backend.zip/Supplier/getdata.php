<table class="table table-bordered table-hover">
	<thead>
	  <tr>
	    <th>Supplier ID</th>
	    <th>Supplier Name</th>
	    <th>Address</th>
	    <th>Contact Number</th>
	    <th>Email</th>
	    <th>Edit/Delete</th>
	  </tr>
	</thead>
	<tbody>
<?php
include "../config.php";
$res = $conn->query("select * from supplier");
while ($row = $res->fetch_assoc()) {
?>
    
	  <tr>
	    <td><?php echo $row['supId']; ?></td>
	    <td><?php echo $row['supName']; ?></td>
	    <td><?php echo $row['address']; ?></td>
	    <td><?php echo $row['contactNo']; ?></td>
	    <td><?php echo $row['email']; ?></td>
	    <td>
	    <a class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal<?php echo $row['supId']; ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
	    <a class="btn btn-danger btn-sm"  onclick="deletedata('<?php echo $row['supId']; ?>')" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>

<!-- Modal -->
<div class="modal fade" id="myModal<?php echo $row['supId']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel<?php echo $row['supId']; ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel<?php echo $row['supId']; ?>">Edit Data</h4>
      </div>
      <div class="modal-body">

<form>
  <div class="form-group">
    <label for="nm">Supplier Name</label>
    <input type="text" class="form-control" id="nm<?php echo $row['supId']; ?>" value="<?php echo $row['supName']; ?>">
  </div>
  <div class="form-group">
    <label for="gd">Address</label>
    <input type="text" class="form-control" id="gd<?php echo $row['supId']; ?>" value="<?php echo $row['address']; ?>">
  </div>
  <div class="form-group">
    <label for="pn">Contact Number</label>
    <input type="text" class="form-control" id="pn<?php echo $row['supId']; ?>" value="<?php echo $row['contactNo']; ?>">
  </div>
  <div class="form-group">
    <label for="al">Email</label>
    <input type="email" class="form-control" id="al<?php echo $row['supId']; ?>" value="<?php echo $row['email']; ?>">
  </div>
</form>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" onclick="updatedata('<?php echo $row['supId']; ?>')" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
	    
	    </td>
	  </tr>
<?php
}
?>
	</tbody>
      </table>